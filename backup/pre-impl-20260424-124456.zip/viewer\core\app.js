import { loadStickyState, state, setActiveTab } from './state.js';
import { RuntimeEvents } from '../contracts/runtime-events.js';
import { renderViewer3D } from '../tabs/viewer3d-tab.js';
import { renderAdvancedGlbViewerPanel } from '../js/pcf2glb/ui/AdvancedGlbViewerPanel.js';
import { renderPcfxConverterTab } from '../tabs/pcfx-converter-tab.js';
import { emit } from './event-bus.js';
import { initDevDebugWindow, destroyDevDebugWindow } from '../debug/dev-debug-window.js';

const TAB_CONFIG_URL = './opt/tab-visibility.json';

const IS_DEV = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';

const TABS = [
  { id: 'viewer3d',  label: '3D Viewer',   render: renderViewer3D },
  ...(IS_DEV ? [{ id: 'adv-glb', label: 'Advanced GLB Viewer', render: renderAdvancedGlbViewerPanel }] : []),
  { id: 'pcfx-converter', label: 'PCF<->PCFX<->GLB', render: renderPcfxConverterTab },
];

let _activeDestroyFn = null;
let _visibleTabs = [...TABS];

export async function init() {
  loadStickyState();
  if (IS_DEV) {
    try { destroyDevDebugWindow(); } catch {}
  }
  _visibleTabs = await _loadVisibleTabs();
  _buildTabBar();
  if (IS_DEV) {
    initDevDebugWindow();
  }
  _switchTab(_resolveInitialTabId());
}

function _buildTabBar() {
  const bar = document.getElementById('tab-bar');
  bar.innerHTML = _visibleTabs.map(t => 
    `<button class="tab-btn" data-tab="${t.id}">${t.label}</button>`
  ).join('');

  bar.addEventListener('click', e => {
    const btn = e.target.closest('.tab-btn');
    if (!btn) return;
    _switchTab(btn.dataset.tab);
  });
}

function _switchTab(tabId) {
  const content = document.getElementById('tab-content');
  setActiveTab(tabId);
  if (_activeDestroyFn) {
      try { _activeDestroyFn(); } catch (err) { console.error(err); }
      _activeDestroyFn = null;
  }
  content.innerHTML = '';
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabId);
  });
  const tabDef = _visibleTabs.find(t => t.id === tabId);
  if (tabDef && tabDef.render) {
    const destroyFn = tabDef.render(content);
    if (typeof destroyFn === 'function') {
        _activeDestroyFn = destroyFn;
    }
  }
}

async function _loadVisibleTabs() {
  try {
    const response = await fetch(TAB_CONFIG_URL, { cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const config = await response.json();
    const visibleTabs = TABS.filter((tab) => _configFlagEnabled(config?.[tab.id]));
    return visibleTabs.length ? visibleTabs : [TABS[0]];
  } catch (error) {
    console.warn('[app] Tab visibility config unavailable, using built-in defaults.', error);
    return [...TABS];
  }
}

function _configFlagEnabled(value) {
  return value === 1 || value === true || value === '1' || value === 'true' || value === 'on';
}

function _resolveInitialTabId() {
  const requested = String(state.activeTab || 'viewer3d');
  const match = _visibleTabs.find((tab) => tab.id === requested);
  return match?.id || _visibleTabs[0]?.id || 'viewer3d';
}
